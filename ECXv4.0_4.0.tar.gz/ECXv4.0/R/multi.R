multi=function ()
{
  require("shiny")





  runApp(system.file("multi",package = "ECXv4.0"))
}
