#Ec= Desired concentration
#output, radius at which that concentration is observed



Radconc=function (Ec = 10, ppm = 10000, mw = 1000, AH = 3) 
{  if (AH < 0.5)   {stop("Introduce an Agar Height value eual or higher than 0.5mm")    }
   if (AH > 6) 	{ stop("Introduce an Agar Height value equal or lower than 6mm") }
   
   rad=19:63
   x=23.44294*exp(-0.0826534*rad)+(325.32176*exp(-0.237215*rad))     
   #adjustment to EC50 package
   y1=-.0538478+(1.0010766*x)-(.0001493*x^2)
   #Adjustment by molecular weight 
   y= y1*( 0.7433336+(0.0033412*mw)+(-1.21E-05*mw^2)+(1.91E-08*mw^3)+(-1.40E-11*mw^4)+(3.92E-15*mw^5))
   
   # Dilution 
   y2=y*(ppm/1000)*(3/AH)
   estim2=which(abs(y2-Ec)==min(abs(y2-Ec)))
   
   
   
   
   if (Ec > max(y2) | Ec <min (y2) ) {
     stop("The value is out of the plate range")
   }
   else 
     return(rad[estim2]+1)
}
