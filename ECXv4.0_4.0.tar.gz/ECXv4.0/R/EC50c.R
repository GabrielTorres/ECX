EC50=function ()
{
  require("shiny")





  runApp(system.file("EC50calc",package = "ECXv4.0"))
}
