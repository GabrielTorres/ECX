
shinyServer(function(input, output) {
  output$contents <- renderTable({


    inFile <- input$file1

    if (is.null(inFile))
      return(NULL)

    read.csv(inFile$datapath, header=T, sep=input$sep,
				 )


  }

  )
   output$contents2 <- renderTable({
     require(EC50v3.1)
   inFile <- input$file1

    if (is.null(inFile))
      return(NULL)

    inft=read.csv(inFile$datapath, header=T, sep=input$sep,
				 )

	ECcal(inft,info=T)
	})


	})
