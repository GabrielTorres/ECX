multi=function ()
{
  require("shiny")





  runApp(system.file("multi",package = "EC50v3.1"))
}
