ECX=function ()
{
  require("shiny")





  runApp(system.file("EC50calc",package = "ECX"))
}
