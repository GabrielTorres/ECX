ppm=function ()
{
  require("shiny")





  runApp(system.file("ppm",package = "EC50v3.1"))
}
