#E50 desired Concentration at radius X (default 20)
#output = initial concentration
ConcCAL=function (E50=100,rad1=42, mw = 1000, AH = 3)  {


{x=23.44294*exp(-0.0826534*(rad1-1))+(325.32176*exp(-0.237215*(rad1-1)))
 #adjustment to EC50 package
 y1=-.0538478+(1.0010766*x)-(.0001493*x^2)
 #Adjusment by molecular weigth
 y= y1*( 0.7433336+(0.0033412*mw)+(-1.21E-05*mw^2)+(1.91E-08*mw^3)+(-1.40E-11*mw^4)+(3.92E-15*mw^5))
}
# Dilution
ppm=E50/(y*(1/1000)*(3/AH))
return (ppm)}#E50 desired Concentration at radius X (default 20)
#output = initial concentration
