#rad1= radius of single value (TER, ER or EC)
#rad2= if rad2 is indicated TER and ER are calculated
#EC= if EC is indicated the EC is calculated
#info= print info
#copy = copy table to clipboard (Windows users)
#write= write table to the working directory
#Paste= read table from Clipboard
#Read= Open a window for select the file
#Sens= Include sensibility (values set by user, default 10000 mg/liter)
#insens= concentration of sensitivity
#intsens = Concentration of intermediate sensitivity





ECcal= function(rad1=NULL,rad2=NULL,EC=NULL,mw=500,ppm=1000,AH=3,iso="Isolate",product="product",ECx=50,info=F,
                copy=F,write=F,Paste=F,Read=T,vol='NULL',sens=T,insens=NULL,intsens=NULL,sep="\t"){
  if(vol!='NULL'){AH=round(vol/(13.9/2)^2 * pi, 2)} else {AH=AH}

  rad1=rad1
  mw=mw
  ppm=ppm
  AH=AH
  product=product
  rad2=rad2
  EC=EC
  ECx=ECx
  if(length(rad1)>=1){Read=F}
  if(length(rad1)>=1&length(AH)==1){AH=rep(AH,length(rad1))}
  if(Paste==T){Read=F}


  a=data.frame()
  if (Paste == T) {if (Sys.info()['sysname']=="Windows"){a = read.table("clipboard", T, sep )}
                    if (Sys.info()['sysname']=="Darwin"){a=read.table(pipe("pbpaste"),sep = sep, header = T)}
                    if (Sys.info()['sysname']=="Linux"){ con1 <- pipe("xclip -selection clipboard -i", open="r")
                    a=read.table( con1, sep=sep, header = T)
                    close(con1)
                    }}


  if (Read==T) {    a = read.csv(file.choose(), T, sep )}
  if(is.data.frame(rad1)==T){ a=rad1}


  if(length(a)!=0){rad1=a$rad1
  mw=a$mw
  ppm=a$ppm
  AH=a$AH
  product=as.character(a$product)
  rad2=a$rad2
  EC=a$EC
  ECx=a$ECx
  iso=as.character(a$iso)}



  for (i in 1:length(rad1)){

    if (rad1[i] < 20) {   stop("Introduce a radius value higher or equal to 20mm")}
    if (rad1[i] > 64) {stop("Introduce a radius value lower or equal to 64mm")}
    if (AH[i] < 0.5) {stop("Introduce an Agar Height value equal or higher than 0.5mm")}
    if (AH [i]> 6) {stop("Introduce an Agar Height value equal or lower than 6mm")}}



  rad=rad1-1
  x=23.44294*exp(-0.0826534*rad)+(325.32176*exp(-0.237215*rad))
  #adjustment to EC50 package
  y1=-.0538478+(1.0010766*x)-(.0001493*x^2)
  #Adjustment by molecular weight
  y= y1*( 0.7433336+(0.0033412*mw)+(-1.21E-05*mw^2)+(1.91E-08*mw^3)+(-1.40E-11*mw^4)+(3.92E-15*mw^5))

  # Dilution
  y2=y*(ppm/1000)*(3/AH)

  #########################################

  rad=rad2-1
  x=23.44294*exp(-0.0826534*rad)+(325.32176*exp(-0.237215*rad))
  #adjustment to EC50 package
  y1=-.0538478+(1.0010766*x)-(.0001493*x^2)
  #Adjustment by molecular weight
  y= y1*( 0.7433336+(0.0033412*mw)+(-1.21E-05*mw^2)+(1.91E-08*mw^3)+(-1.40E-11*mw^4)+(3.92E-15*mw^5))

  # Dilution
  y3=y*(ppm/1000)*(3/AH)

  #########################################
  rad=EC-1
  x=23.44294*exp(-0.0826534*rad)+(325.32176*exp(-0.237215*rad))
  #adjustment to EC50 package
  y1=-.0538478+(1.0010766*x)-(.0001493*x^2)
  #Adjustment by molecular weight
  y= y1*( 0.7433336+(0.0033412*mw)+(-1.21E-05*mw^2)+(1.91E-08*mw^3)+(-1.40E-11*mw^4)+(3.92E-15*mw^5))

  # Dilution
  y4=y*(ppm/1000)*(3/AH)
  TER=NULL
  ER=NULL
  EC1=NULL
  Sensitivity=NULL
  Sensitivity1=NULL
  for(i in 1:length(y2)){TER[i]=round(max(y2[i],y3[i],y4[i],na.rm = T),5)
  ER[i]=round(min(y2[i],y3[i],y4[i],na.rm = T),5)
  EC1[i]=round(median(c(y2[i],y3[i],y4[i])),5)
  }

  if(length (rad2)==0&length(EC)==0){ER=NULL
  EC1=TER
  TER=NULL}
  if(length (rad2)==0&length(EC)!=0){EC1=ER
  ER=NULL
  }
  if(length (rad1)!=0&length (rad2)!=0&length(EC)==0){EC1=NULL
 }
  for (i in 1:length(EC1)){Sensitivity[i]= ifelse(EC1[i]>insens,"INS",ifelse(EC1[i]<intsens,"SEN","INT"))}
  if(sens==F){Sensitivity=Sensitivity1}
  total = as.data.frame(cbind(TIC=TER ,MIC=ER , EC=EC1,Sensitivity))
  if(info==T) {total=as.data.frame(cbind(Isolate=iso,Product=product,mw=mw,ppm=ppm,"ah"=AH,TIC=TER,MIC=ER,"ECx"=ECx,EC=EC1,Sensitivity))}
  if (copy == T) {if (Sys.info()['sysname']=="Windows"){write.table(total, "clipboard", sep = "\t", row.names = FALSE)}
    if(Sys.info()['sysname']=="Darwin"){write.table(total,pipe("pbcopy", "w"),sep = "\t", row.names = FALSE)}
    if(Sys.info()['sysname']=="Linux"){con <- pipe("xclip -selection clipboard -i", open="w")
    write.table(total, con, sep=sep, row.names=F, col.names=T)
    close(con)}
  }

   if (write == T) {write.csv(total, file=paste('ECvalues-', Sys.Date(),format(Sys.time(),"-%H-%M-%S-%p"),".csv",sep = ""),  row.names = FALSE)}
  return((total))
}
