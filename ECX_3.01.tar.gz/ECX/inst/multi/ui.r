library(shiny)

shinyUI(fluidPage(
  titlePanel("EC calculator"),
  sidebarLayout(
    sidebarPanel(
      fileInput('file1', 'Choose CSV File',
                accept=c('text/csv',
								 'text/comma-separated-values,text/plain',
								 '.csv')),
      tags$hr(),


	        radioButtons('sep', 'Separator',
                   c(Comma=',',
                     Semicolon=';',
                     Tab='\t'),
                   ',')


    ),
    mainPanel(
	 #tableOutput('contents')
	tabsetPanel(
        id = 'EC',
        tabPanel('Table', tableOutput('contents')),
        tabPanel('Results',tableOutput('contents2'),"EC= Effective concentration   MIC=Minimum inhibition concentration  TIC=Total inhibition concentration ")
	)


    )
  )
))
