library(shiny)

spcalt= function(rad1=20,rad2=64,ec=43,ECx=50,mw=500,ppm=1000,AH=3,product="product",copy=F,write=F,vol='NULL'){
  if(vol!='NULL'){AH=round(vol/(13.9/2)^2 * pi, 2)}
  if (rad1 < 20) {
    stop("Introduce a radius value higher or equal to 20mm")
  }
  else if (rad2 > 64) {
    stop("Introduce a radius value lower or equal to 64mm")
  }
  if (AH < 0.5) {
    stop("Introduce an Agar Height value equal or higher than 0.5mm")
  }
  else if (AH > 6) {
    stop("Introduce an Agar Height value equal or lower than 6mm")
  }
  else if (rad1 > rad2) {
    stop("Total inhibition concentration TIC (rad1) cannot be higher than Minimum inhibition concentration MIC(rad2)")
  }
  else if (ECx > 99) {
    stop("EC value range between 1 and 99")
  }
  else if (ECx < 1) {
    stop("EC value range between 1 and 99")
  }



  rad=rad1-1
  if(rad2!=0){rad=seq(rad1-1,rad2-1,by=2)}
  mw=mw
  #model for initial dilution
  inic=function(rad,mw){x=23.44294*exp(-0.0826534*rad)+(325.32176*exp(-0.237215*rad))
                        #adjustment to EC50 package
                        y1=-.0538478+(1.0010766*x)-(.0001493*x^2)
                        #Adjusment by molecular weigth
                        y= y1*( 0.7433336+(0.0033412*mw)+(-1.21E-05*mw^2)+(1.91E-08*mw^3)+(-1.40E-11*mw^4)+(3.92E-15*mw^5))
  }
  # Dilution
  y=inic(rad,mw)*(ppm/1000)*(3/AH)


 
  ug.ml = y
  total = cbind(Radius = seq(rad1, rad2,by=2), ug.ml)
  layout(1)
  par(mar = c(5.1, 4.1, 4.1, 2.1))

  if (copy == T) {if (Sys.info()['sysname']=="Windows"){write.table(total, "clipboard", sep = "\t", row.names = FALSE)}
                  if(Sys.info()['sysname']=="Darwin"){write.table(total,pipe("pbcopy", "w"),sep = "\t", row.names = FALSE)}
                  if(Sys.info()['sysname']=="Linux"){con <- pipe("xclip -selection clipboard -i", open="w")
                  write.table(total, con, sep='\t', row.names=F)
                   close(con)}
    }
  if (write == T) {write.csv(total, file=paste('ECvalues-', Sys.Date(),format(Sys.time(),"-%H-%M-%S-%p"),".csv",sep = ""),  row.names = FALSE)}
  return((total))
}

########################################################################

shinyServer(function(input, output) {


  output$summary<-renderTable({

        as.data.frame(
				(spcalt(rad1=input$rad1,rad2=input$rad2,ppm=input$ppm,mw=input$mw,
                  product=input$product,AH=input$AH,ECx=input$ECx)))
                  })
output$summary1<-renderText({
                 y= paste("EC",input$ECs,"was found at radius",round(spcalt(rad1=input$ECx,rad2=input$ECx,ppm=input$ppm,mw=input$mw,
                  product=input$product,AH=input$AH,ECx=input$ECx),5),sep=" ")
				print(y)
	   })

  output$summary2<-renderPlot({
  y=spcalt(rad1=input$rad1,rad2=input$rad2,ppm=input$ppm,mw=input$mw,
                  product=input$product,AH=input$AH,ECx=input$ECx)
				  ecx=round(spcalt(rad1=input$ECx,rad2=input$ECx,ppm=input$ppm,mw=input$mw,
                  product=input$product,AH=input$AH,ECx=input$ECx),5)
					plot(y,col=2,pch=19,main="(ug/ml)at X radius")
						text(mean(y[,1]), (max(y[,2]) * 0.95), paste("ECx", "=", round(max(ecx[,2]),5)),col=4)
						text(mean(y[,1]), (max(y[,2]) * 0.80), paste("TIC", "=", round(max(y[,2]),5)))
						text(mean(y[,1]), (max(y[,2]) * 0.70), paste("MIC", "=", round(min(y[,2]),5)))
						points(ecx,pch=19,col=4)
  })



        output$View<-renderPlot({
            y=spcalt(rad1=input$rad1,rad2=input$rad2,ppm=input$ppm,mw=input$mw,
                  product=input$product,AH=input$AH,ECx=input$ECx)
				  ecx=round(spcalt(rad1=input$ECx,rad2=input$ECx,ppm=input$ppm,mw=input$mw,
                  product=input$product,AH=input$AH,ECx=input$ECx),5)
				  
				   m=lm(log10(y[,2])~y[,1])
  eq <- substitute(italic(y) == a + b %.% italic(x)*","~~italic(r)^2~"="~r2,
                   list(a = format(coef(m)[1], digits = 5),
                        b = format(coef(m)[2], digits = 5),
                        r2 = format(summary(m)$r.squared, digits = 5)))
						as.character(as.expression(eq)   )
						a=as.numeric(format(coef(m)[1], digits = 5))
						b =as.numeric (format(coef(m)[2], digits = 5))
						estim=(a)+((b)*(y[,1]))
				  
				  plot(y[,1],estim,col=2,pch=19,main="Linear Regression",type="l",xlab="Radius in mm", ylab="Log10 (Concentration)") 
					text(mean(y[,1]), (max(estim) * 0.70), eq)
					lines(c(input$ECx,input$ECx),c(min(estim),(a + (b * input$ECx))),col=4)

				  })
output$downloadData <- downloadHandler(
filename = function() {
paste("data-", Sys.Date(), ".csv", sep="")
},
content = function(file) {write.csv(
                             spcalt(rad1=input$rad1,rad2=input$rad2,ppm=input$ppm,mw=input$mw,
                  product=input$product,AH=input$AH,ECx=input$ECx), file.choose(),row.names=F)
}
)
output$downloadPic <- downloadHandler(
   filename = function() {

    paste('image-', Sys.time(), '.jpeg', sep='')
  },
 content = function(con) {
  y=spcalt(rad1=input$rad1,rad2=input$rad2,ppm=input$ppm,mw=input$mw,
                  product=input$product,AH=input$AH,ECx=input$ECx)
				  ecx=round(spcalt(rad1=input$ECx,rad2=input$ECx,ppm=input$ppm,mw=input$mw,
                  product=input$product,AH=input$AH,ECx=input$ECx),5)
					#jpeg(paste('image-', Sys.Date(), '.jpg', sep=''))
					jpeg(file.choose(),res=100, width = 1024, height = 768,pointsize=18)
					plot(y,col=2,pch=19,main="(ug/ml)at X radius")
						text(mean(y[,1]), (max(y[,2]) * 0.95), paste("ECx", "=", round(max(ecx[,2]),5)),col=4)
						text(mean(y[,1]), (max(y[,2]) * 0.80), paste("TIC", "=", round(max(y[,2]),5)))
						text(mean(y[,1]), (max(y[,2]) * 0.70), paste("MIC", "=", round(min(y[,2]),5)))
						points(ecx,pch=19,col=4)
						dev.off()
  }
 )

output$downloadPic2 <- downloadHandler(
   filename = function() {

    paste('image-', Sys.time(), '.jpeg', sep='')
  },
 content = function(con) {
   y=spcalt(rad1=input$rad1,rad2=input$rad2,ppm=input$ppm,mw=input$mw,
                  product=input$product,AH=input$AH,ECx=input$ECx)
				  ecx=round(spcalt(rad1=input$ECx,rad2=input$ECx,ppm=input$ppm,mw=input$mw,
                  product=input$product,AH=input$AH,ECx=input$ECx),5)
				  
				   m=lm(log10(y[,2])~y[,1])
  eq <- substitute(italic(y) == a + b %.% italic(x)*","~~italic(r)^2~"="~r2,
                   list(a = format(coef(m)[1], digits = 5),
                        b = format(coef(m)[2], digits = 5),
                        r2 = format(summary(m)$r.squared, digits = 5)))
						as.character(as.expression(eq)   )
						a=as.numeric(format(coef(m)[1], digits = 5))
						b =as.numeric (format(coef(m)[2], digits = 5))
						estim=(a)+((b)*(y[,1]))
				  jpeg(file.choose(),res=100, width = 1024, height = 768,pointsize=18)
				  plot(y[,1],estim,col=2,pch=19,main="Linear Regression",type="l",xlab="Radius in mm", ylab="Log10 (Concentration)") 
					text(mean(y[,1]), (max(estim) * 0.70), eq)
					lines(c(input$ECx,input$ECx),c(min(estim),(a + (b * input$ECx))),col=4)
					dev.off()
  }
 )


})
