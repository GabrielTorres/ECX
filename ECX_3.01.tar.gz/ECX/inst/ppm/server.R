
shinyServer(function(input, output) {
  output$ppmr <- renderText({
    
 conc = round(input$dc*input$vol/(input$percent*10000), 3)
   val = ifelse(input$units=="l","ml","g")
   if (conc<1){	val=ifelse(input$units=="l","ul","mg")
                conc=conc*1000}
   
   vol=input$vol
   fv="ml of"
   if(input$vol>=1000){fv="liters of"
   vol=input$vol/1000}
   
   
   
   pp1 = paste("To obtain",vol,fv ,input$product, "at ", input$dc, 
               "mg/liter, mix", conc, val, "of", input$product, "and set the final volume to", 
               input$vol,"ml")
   pp1

  

  }
  
  )


	
	})
	