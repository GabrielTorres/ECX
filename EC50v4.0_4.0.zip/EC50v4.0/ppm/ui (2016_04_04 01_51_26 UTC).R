library(shiny)

shinyUI(fluidPage(
  titlePanel("ppm calculator"),
  sidebarLayout(
    sidebarPanel(
	textInput('product','Product name:',"Product"),
      numericInput('percent', 'Percentage A.I.', 100,0,100),

	        radioButtons('units', 'State of the A.I.',
                   c(Liquid='l',
                     Solid='s'
                     ),
                   'l'),
				   
numericInput('dc', 'Desired concentration in mg/liter', 100,0),
numericInput('vol', 'Desired final volume in ml', 1000,0)
				 
     
    ),
    mainPanel(
	textOutput('ppmr')
	)
	
     
    )
  )
)