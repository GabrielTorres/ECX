
library(shiny)
Conc2=function(rad1=20,rad2=64,ppm=1000,mw=1000,product="fungicide",AH=3,day=1,ECx=50,para=as.numeric(estim2)){
  if(rad1<20){stop("Introduce a radius value higher or equal to 20mm")}else
    if (rad2>64){stop("Introduce a radius value lower or equal to 64mm")}else
      if(AH<0.5){stop("Introduce an Agar Height value eual or higher than 0.5mm")}else
        if(AH>6){stop("Introduce an Agar Height value equal or lower than 6mm")}else
          if (rad1>rad2){stop("Tail ending radius (rad1) cannot be higher than Ending radius(rad2)")}else
            if(ECx>99){stop("EC value range between 1 and 100")}else
              if(ECx<1){stop("EC value range between 1 and 100")}else
                          if(day>2){stop("The product diffusion is reached at 48 hours after plate preparation; inotroduce 1 or 2 days as value")}


  #Initial dilution from R linearization
  #lm.1 <- lm(y ~ x + I(x^2) + I(x^3)+I(x^4)+ I(x^5)+ I(x^6))
  #step(lm.1)--> to identify the proper model
  indil1=(((168.2) + (-0.03732 * mw) + ((-0.0003756) * mw^2) +
             ((6.436e-07) * mw^3) + ((-2.901e-10) * mw^4)) * (ppm/10000)*3/(AH))
  "day function"
  v3=(3.437e-01+(1.950e-03*mw)+(-6.160e-06*mw^2)+(1.343e-08*mw^3)+(-1.626e-11*mw^4)+(9.428e-15*mw^5)+(-1.985e-18*mw^6))

  if (day==1){indil=indil1}else
    if(day>1){indil=indil1*((v3)^(day-1))}

  v=(mw)
  Dr=(1.161+((6.341e-04)*v)-((1.281e-06)*v^2)+
        ((1.187e-09)*v^3)-((4.163e-13)*v^4))
  ug.ul = indil
  ECx1=(rad1+((rad2-rad1)/100*(100-ECx)))
  n = 23
  for(i in 2:n){
    ug.ul[i] = ug.ul[i-1]/Dr}
  (round((ug.ul),3))
  Rad=seq(20,64,2)

  dep=(ug.ul)
  ind=Rad
  m=lm(log10(dep)~ind)
  eq <- substitute(italic(y) == a + b %.% italic(x)*","~~italic(r)^2~"="~r2,
                   list(a = format(coef(m)[1], digits = 5),
                        b = format(coef(m)[2], digits = 5),
                        r2 = format(summary(m)$r.squared, digits = 5)))
  as.character(as.expression(eq)   )
  a=as.numeric(format(coef(m)[1], digits = 5))
  b =as.numeric (format(coef(m)[2], digits = 5))
  estim=(a)+((b)*(seq(rad1,rad2)))
  estim2=10^(estim)
  estim3=(a+((b)*ECx1))
  estim3.1=10^(estim3)
  E50=round(10^((a)+((b)*(ECx1))),5)
  para=as.vector(paste(para))
  return(estim2)
 }
Conc2.1=function(rad1=20,rad2=64,ppm=1000,mw=1000,product="fungicide",AH=3,day=1,ECx=50){
  if(rad1<20){stop("Introduce a radius value higher or equal to 20mm")}else
    if (rad2>64){stop("Introduce a radius value lower or equal to 64mm")}else
      if(AH<0.5){stop("Introduce an Agar Height value eual or higher than 0.5mm")}else
        if(AH>6){stop("Introduce an Agar Height value equal or lower than 6mm")}else
          if (rad1>rad2){stop("Tail ending radius (rad1) cannot be higher than Ending radius(rad2)")}
           indil1=(((168.2) + (-0.03732 * mw) + ((-0.0003756) * mw^2) +
             ((6.436e-07) * mw^3) + ((-2.901e-10) * mw^4)) * (ppm/10000)*3/(AH))
  "day function"
  v3=(3.437e-01+(1.950e-03*mw)+(-6.160e-06*mw^2)+(1.343e-08*mw^3)+(-1.626e-11*mw^4)+(9.428e-15*mw^5)+(-1.985e-18*mw^6))

  if (day==1){indil=indil1}else
    if(day>1){indil=indil1*((v3)^(day-1))}

  v=(mw)
  Dr=(1.161+((6.341e-04)*v)-((1.281e-06)*v^2)+
        ((1.187e-09)*v^3)-((4.163e-13)*v^4))
  ug.ul = indil
  ECx1=(rad1+((rad2-rad1)/100*(100-ECx)))
  n = 23
  for(i in 2:n){
    ug.ul[i] = ug.ul[i-1]/Dr}
  (round((ug.ul),3))
  Rad=seq(20,64,2)

  dep=(ug.ul)
  ind=Rad
  m=lm(log10(dep)~ind)
  eq <- substitute(italic(y) == a + b %.% italic(x)*","~~italic(r)^2~"="~r2,
                   list(a = format(coef(m)[1], digits = 5),
                        b = format(coef(m)[2], digits = 5),
                        r2 = format(summary(m)$r.squared, digits = 5)))
  as.character(as.expression(eq)   )
  a=as.numeric(format(coef(m)[1], digits = 5))
  b =as.numeric (format(coef(m)[2], digits = 5))
  estim=(a)+((b)*(seq(rad1,rad2)))
  estim2=10^(estim)
  E50=round(10^((a)+((b)*(ECx1))),5)
  return(eq) }
Conc2.2=function(rad1=20,rad2=64,ppm=1000,mw=1000,product="fungicide",AH=3,day=1,ECx=50){
  if(rad1<20){stop("Introduce a radius value higher or equal to 20mm")}else
    if (rad2>64){stop("Introduce a radius value lower or equal to 64mm")}else
      if(AH<0.5){stop("Introduce an Agar Height value eual or higher than 0.5mm")}else
        if(AH>6){stop("Introduce an Agar Height value equal or lower than 6mm")}else
          if (rad1>rad2){stop("Tail ending radius (rad1) cannot be higher than Ending radius(rad2)")}
           indil1=(((168.2) + (-0.03732 * mw) + ((-0.0003756) * mw^2) +
             ((6.436e-07) * mw^3) + ((-2.901e-10) * mw^4)) * (ppm/10000)*3/(AH))
  "day function"
  v3=(3.437e-01+(1.950e-03*mw)+(-6.160e-06*mw^2)+(1.343e-08*mw^3)+(-1.626e-11*mw^4)+(9.428e-15*mw^5)+(-1.985e-18*mw^6))

  if (day==1){indil=indil1}else
    if(day>1){indil=indil1*((v3)^(day-1))}

  v=(mw)
  Dr=(1.161+((6.341e-04)*v)-((1.281e-06)*v^2)+
        ((1.187e-09)*v^3)-((4.163e-13)*v^4))
  ug.ul = indil
  ECx1=(rad1+((rad2-rad1)/100*(100-ECx)))
  n = 23
  for(i in 2:n){
    ug.ul[i] = ug.ul[i-1]/Dr}
  (round((ug.ul),3))
  Rad=seq(20,64,2)

  dep=(ug.ul)
  ind=Rad
  m=lm(log10(dep)~ind)
  eq <- substitute(italic(y) == a + b %.% italic(x)*","~~italic(r)^2~"="~r2,
                   list(a = format(coef(m)[1], digits = 5),
                        b = format(coef(m)[2], digits = 5),
                        r2 = format(summary(m)$r.squared, digits = 5)))
  as.character(as.expression(eq)   )
  a=as.numeric(format(coef(m)[1], digits = 5))
  b =as.numeric (format(coef(m)[2], digits = 5))
  estim=(a)+((b)*(seq(rad1,rad2)))
  estim2=10^(estim)
  E50=round(10^((a)+((b)*(ECx1))),5)
  return(a) }
Conc2.3=function(rad1=20,rad2=64,ppm=1000,mw=1000,product="fungicide",AH=3,day=1,ECx=50){
  if(rad1<20){stop("Introduce a radius value higher or equal to 20mm")}else
    if (rad2>64){stop("Introduce a radius value lower or equal to 64mm")}else
      if(AH<0.5){stop("Introduce an Agar Height value eual or higher than 0.5mm")}else
        if(AH>6){stop("Introduce an Agar Height value equal or lower than 6mm")}else
          if (rad1>rad2){stop("Tail ending radius (rad1) cannot be higher than Ending radius(rad2)")}


  #Initial dilution from R linearization
  #lm.1 <- lm(y ~ x + I(x^2) + I(x^3)+I(x^4)+ I(x^5)+ I(x^6))
  #step(lm.1)--> to identify the proper model
  indil1=(((168.2) + (-0.03732 * mw) + ((-0.0003756) * mw^2) +
             ((6.436e-07) * mw^3) + ((-2.901e-10) * mw^4)) * (ppm/10000)*3/(AH))
  "day function"
  v3=(3.437e-01+(1.950e-03*mw)+(-6.160e-06*mw^2)+(1.343e-08*mw^3)+(-1.626e-11*mw^4)+(9.428e-15*mw^5)+(-1.985e-18*mw^6))

  if (day==1){indil=indil1}else
    if(day>1){indil=indil1*((v3)^(day-1))}

  v=(mw)
  Dr=(1.161+((6.341e-04)*v)-((1.281e-06)*v^2)+
        ((1.187e-09)*v^3)-((4.163e-13)*v^4))
  ug.ul = indil
  ECx1=(rad1+((rad2-rad1)/100*(100-ECx)))
  n = 23
  for(i in 2:n){
    ug.ul[i] = ug.ul[i-1]/Dr}
  (round((ug.ul),3))
  Rad=seq(20,64,2)

  dep=(ug.ul)
  ind=Rad
  m=lm(log10(dep)~ind)
  eq <- substitute(italic(y) == a + b %.% italic(x)*","~~italic(r)^2~"="~r2,
                   list(a = format(coef(m)[1], digits = 5),
                        b = format(coef(m)[2], digits = 5),
                        r2 = format(summary(m)$r.squared, digits = 5)))
  as.character(as.expression(eq)   )
  a=as.numeric(format(coef(m)[1], digits = 5))
  b =as.numeric (format(coef(m)[2], digits = 5))
  estim=(a)+((b)*(seq(rad1,rad2)))
  estim2=10^(estim)
  E50=round(10^((a)+((b)*(ECx1))),5)
  return(b) }


  Conc2.4=function(rad1=20,rad2=64,ppm=1000,mw=1000,product="fungicide",AH=3,day=1,ECx=50){
  if(rad1<20){stop("Introduce a radius value higher or equal to 20mm")}else
    if (rad2>64){stop("Introduce a radius value lower or equal to 64mm")}else
      if(AH<0.5){stop("Introduce an Agar Height value eual or higher than 0.5mm")}else
        if(AH>6){stop("Introduce an Agar Height value equal or lower than 6mm")}else
          if (rad1>rad2){stop("Tail ending radius (rad1) cannot be higher than Ending radius(rad2)")}
           indil1=(((168.2) + (-0.03732 * mw) + ((-0.0003756) * mw^2) +
             ((6.436e-07) * mw^3) + ((-2.901e-10) * mw^4)) * (ppm/10000)*3/(AH))
  "day function"
  v3=(3.437e-01+(1.950e-03*mw)+(-6.160e-06*mw^2)+(1.343e-08*mw^3)+(-1.626e-11*mw^4)+(9.428e-15*mw^5)+(-1.985e-18*mw^6))

  if (day==1){indil=indil1}else
    if(day>1){indil=indil1*((v3)^(day-1))}

  v=(mw)
  Dr=(1.161+((6.341e-04)*v)-((1.281e-06)*v^2)+
        ((1.187e-09)*v^3)-((4.163e-13)*v^4))
  ug.ul = indil
  ECx1=(rad1+((rad2-rad1)/100*(100-ECx)))
  n = 23
  for(i in 2:n){
    ug.ul[i] = ug.ul[i-1]/Dr}
  (round((ug.ul),3))
  Rad=seq(20,64,2)

  dep=(ug.ul)
  ind=Rad
  m=lm(log10(dep)~ind)
  eq <- substitute(italic(y) == a + b %.% italic(x)*","~~italic(r)^2~"="~r2,
                   list(a = format(coef(m)[1], digits = 5),
                        b = format(coef(m)[2], digits = 5),
                        r2 = format(summary(m)$r.squared, digits = 5)))
  as.character(as.expression(eq)   )
  a=as.numeric(format(coef(m)[1], digits = 5))
  b =as.numeric (format(coef(m)[2], digits = 5))
  estim=(a)+((b)*(seq(rad1,rad2)))
  estim2=10^(estim)
  E50=round(10^((a)+((b)*(ECx1))),5)
  return(E50) }

circle=function (x, y, radius, nv = 100, border = NULL, col = NA, lty = 1,
                 lwd = 1){
  xylim <- par("usr")
  plotdim <- par("pin")
  ymult <- (xylim[4] - xylim[3])/(xylim[2] - xylim[1]) * plotdim[1]/plotdim[2]
  angle.inc <- 2 * pi/nv
  angles <- seq(0, 2 * pi - angle.inc, by = angle.inc)
  if (length(col) < length(radius))
    col <- rep(col, length.out = length(radius))
  for (circle in 1:length(radius)) {
    xv <- cos(angles) * radius[circle] + x
    yv <- sin(angles) * radius[circle] * ymult + y
    polygon(xv, yv, border = border, col = col[circle], lty = lty,
            lwd = lwd)
  }
  invisible(list(x = xv, y = yv))
}
plot1=function(rad1=20,rad2=64,ppm=1000,mw=1000,
             product="fungicide",AH=3,day=1,ECx=50){
Radius=seq(rad1,rad2)
ECx1=rad1+((rad2-rad1)/100*(100-ECx))
ug.ul=log10(Conc2(rad1,rad2,ppm,mw,product,AH,day,ECx))
Conc51=Conc2.2(rad1,rad2,ppm,mw,product,AH,day,ECx)+(Conc2.3(rad1,rad2,ppm,mw,product,AH,day,ECx)*ECx1)
plot(Radius,ug.ul,main=paste("Linear Regresion of",product,"at",ppm,"ppm"),ylab="Log ug/ml")
lines(Radius,ug.ul,col=2)
points(ECx1,Conc51,pch=19,col=4,cex=2)
text(ECx1+1,Conc51,paste("EC",ECx,",","Radius=",ECx1),pos=4,col=4,cex=1.5,font=2)
text(mean(Radius),max(ug.ul),Conc2.1(rad1,rad2,ppm,mw,product,AH,day,ECx),cex=1.5, font=2)}
##
plot2=function(rad1=20,rad2=64,ppm=1000,mw=1000,
               product="fungicide",AH=3,day=1,ECx=50){
Radius=seq(rad1,rad2)
ug.ul=Conc2(rad1,rad2,ppm,mw,product,AH,day,ECx)
ECx1=rad1+((rad2-rad1)/100*(100-ECx))
Conc51=Conc2.2(rad1,rad2,ppm,mw,product,AH,day,ECx)+(Conc2.3(rad1,rad2,ppm,mw,product,AH,day,ECx)*ECx1)
E5=function(x){
  if(x<=1){print(4)}else
    if(x<85){print(2)}}
E6=function(x){
  if(x>=90){print(0)}else
    if(x<10){print(0)}else
      if(x>=10){1}}
plot(Radius,ug.ul,main=paste(product,ppm,"ppm"),ylab="ug/ml")
lines(Radius,ug.ul,col=2)
points(c(rad1,rad2,ECx1),c(max(ug.ul),
        min (ug.ul),10^Conc51),col=c(3,2,4),pch=16,cex=1.5)
text(c(rad1,rad2,mean(rad1:rad2)),c(max(ug.ul),
  min (ug.ul),(max(ug.ul)*.9)),c(paste("Min",round(max(ug.ul),5)),
   paste("Max",round(min (ug.ul),5)), paste("EC",ECx,":",round(10^Conc51,5))),
     pos=c(4,3,1)
     ,col=c(E6(ECx),E6(ECx),4),font=2,cex=c(1,1,1.5))}

##
plot3=function(rad1=20,rad2=64,ppm=1000,mw=1000,
               product="fungicide",AH=3,day=1,ECx=50){
ug.ul=Conc2(rad1,rad2,ppm,mw,product,AH,day,ECx)
ECx1=rad1+((rad2-rad1)/100*(100-ECx))
Conc51=Conc2.2(rad1,rad2,ppm,mw,product,AH,day,ECx)+(Conc2.3(rad1,rad2,ppm,mw,product,AH,day,ECx)*ECx1)
plot(-70:70,-70:70,type="n",xlab="Radius",ylab="",yaxt='n',
     xaxt='n',main=(paste(product,ppm,"ppm")))
circle(0,0,seq(20,64,2))
circle(0,0,seq(20,64,10),border=4,lwd=2)
text(seq(-20,-64,-10),0,seq(20,64,10),font=2)
rad12=rad1
rad22=rad2
polygon(c(20,rad12,rad12,20),c(2.5,2.5,-2.5,-2.5),col=5,border=5)
polygon(c(rad12,rad22,64,64,rad22,
          rad12),c(2.5,10,10,-10,-10,-2.5),col=2)
circle(0,0,ECx1,border=7,lwd=2)
text(ECx1,0,paste("EC",ECx,":",round(10^Conc51,5)),col=0,pos=4,font=2)
}
shinyServer(function(input, output) {


  output$summary<-renderTable({

        as.data.frame(cbind(Radius=seq(input$rad1,input$rad2),
                             "ug/ml"=Conc2(input$rad1,input$rad2,input$ppm,input$mw,
                  input$product,input$AH,input$day,input$ECx)))
                  })
output$summary1<-renderText({
                  as.character(paste("EC",input$ECx,"=",a=Conc2.4(input$rad1,input$rad2,input$ppm,input$mw,
                  input$product,input$AH,input$day,input$ECx)))
        })

  output$summary2<-renderPlot({
    plot1(input$rad1,input$rad2,input$ppm,input$mw,
                  input$product,input$AH,input$day,input$ECx)

  })

  output$summary3<-renderPlot({
    plot3(input$rad1,input$rad2,input$ppm,input$mw,
                  input$product,input$AH,input$day,input$ECx)
  })

        output$View<-renderPlot({
          plot2(input$rad1,input$rad2,input$ppm,input$mw,
                input$product,input$AH,input$day,input$ECx)   })
output$downloadData <- downloadHandler(
filename = function() {
paste("data", Sys.Date(), ".csv", sep="")
},
content = function(file) {write.csv((cbind(Radius=seq(input$rad1,input$rad2),
                             ug.ul=Conc2(input$rad1,input$rad2,input$ppm,input$mw,
                                         input$product,input$AH,input$day,input$ECx))), file)
}
)



  output$downloadData.plot3 <- downloadHandler(
    filename = function() {
      paste(input$product,input$ppm,'ppm', Sys.time(),'.png',sep='')
    },
    content = function(file) {
      png(paste("plots/","LRplot",input$product,input$ppm,"ppm",".png"),width = 980, height = 400, units = "px", pointsize = 12, bg = "white", res = NA)
plot1(input$rad1,input$rad2,input$ppm,input$mw,
      input$product,input$AH,input$day,input$ECx)

      dev.off()},
    contentType = 'image/png'
  )

output$downloadData.plot2 <- downloadHandler(
  filename <- function() {
    paste(input$product,input$ppm,'ppm', Sys.time(),'.png',sep='')
  },
  content = function(file) {
    png(paste("plots/","Plate_plot",input$product,input$ppm,"ppm",".png"))
    plot3(input$rad1,input$rad2,input$ppm,input$mw,
          input$product,input$AH,input$day,input$ECx)
    dev.off()},
  contentType = 'image/png'
)
  output$downloadData.plot1 <- downloadHandler(
    filename <- function() {
      paste(input$product,input$ppm,'ppm', Sys.time(),'.png',sep='')
    },
    content = function(file) {
      png(paste("plots/","Dil_plot",input$product,input$ppm,"ppm",".png"))
      plot2(input$rad1,input$rad2,input$ppm,input$mw,
            input$product,input$AH,input$day,input$ECx)
      dev.off()},
    contentType = 'image/png'
  )
})
