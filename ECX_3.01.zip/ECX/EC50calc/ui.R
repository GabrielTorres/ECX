# Define UI for miles per gallon application
shinyUI(pageWithSidebar(

  # Application title
  headerPanel("EC X Calculator"),

  sidebarPanel(
    textInput("product", "Product:", "name"),
    numericInput("AH", "Agar Height (introduce a value between 0.5 and 6:",
                min=0.5,
                max=6,
                value=3),
    sliderInput("rad1",
                "Total inhibition concentration - TIC",
                min = 20,
                max = 64,
                value = 20),
    sliderInput("rad2",
                "Minimum inhibition concentration - MIC ",
                min = 20,
                max = 64,
                value = 64),
    numericInput("mw", "Molecular Weight:", 500),
    numericInput("ppm", "Parts per million:", 1000),
	numericInput("ECs","Effective concentration evaluated:",50),
    numericInput("ECx","Effective Concentration (ECx) was found at radius:",50)
	


    ),

  mainPanel(

    tabsetPanel(
      tabPanel("Plot",downloadButton('downloadPic','Download Graph'),plotOutput("summary2")),
        tabPanel("Table",h4("Table"),textOutput("summary1"),tableOutput("summary"),downloadButton("downloadData", "Download Table")),
      tabPanel("Regression  Model",downloadButton('downloadPic2','Download Graph'),plotOutput("View")))



)))
